#include <stdio.h>
void main()

{
    int angle_x, angle_y, angle_z;
    printf("enter angle_x: ");
    scanf("%d", &angle_x);
    
    printf("enter angle_y: ");
    scanf("%d", &angle_y);

    printf("enter anle_z: ");
    scanf("%d", &angle_z);

    if (angle_x+angle_y+angle_z==180)
    {
        printf("Yes a triangle can be formed");
    }
    else
    {
        printf("this is not a triangle");
    }
    
}