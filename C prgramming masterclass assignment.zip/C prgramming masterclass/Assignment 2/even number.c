#include <stdio.h>

int main()
{
    int num1;
    printf("enter number; ");
    scanf("%d", &num1);

    if (num1%2==0)
    {
        printf("the numbers is even.\n");
    }
    
}