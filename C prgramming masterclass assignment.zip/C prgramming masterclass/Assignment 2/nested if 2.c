#include <stdio.h>
void main()

{
    int num;

    printf("enter a number: ");
    scanf("%d", &num);

    if (num>0)
    {
        if (num%2==0)
        {
            printf("num is positive and even");
        }else{
            printf("number is positive and odd");
        }
        
    }else{
        if (num<0)
        {
            printf("number is negative");
        }else{
            printf("number is 0");
        }
        
    }
    
}