#include <stdio.h>

int main() {
    char choice; 
    float a, b, c;

    printf("+ Addition\n");
    printf("- Subtraction\n");
    printf("* Multiplication\n");
    printf("/ Division\n");
    printf("Enter operator: ");
    scanf(" %c", &choice); 

    printf("Enter numbers a and b: ");
    scanf("%f %f", &a, &b);

    switch(choice) {
        case '+':
            c = a + b;
            printf("Result: %.2f\n", c);
            break;
        case '-':
            c = a - b;
            printf("Result: %.2f\n", c);
            break;
        case '*':
            c = a * b;
            printf("Result: %.2f\n", c);
            break;
        case '/':
            if (b != 0) {
                c = a / b;
                printf("Result: %.2f\n", c);
            } else {
                printf("Error: Division by zero is not allowed.\n");
            }
            break;
        default:
            printf("Error: Invalid operator! Please use +, -, *, or /.\n");
    }
    
    return 0;
}
