#include <stdio.h>
void main()
{
    int m, n;
    printf("enter m: ");
    scanf("%d", &m);

    if (m>0)
    {
        printf("n=1");
    }
 else
    {
        if (m<0)
        {
            printf("n=-1");
        }
        else
        {
            printf("n=0");
        }
    }
}