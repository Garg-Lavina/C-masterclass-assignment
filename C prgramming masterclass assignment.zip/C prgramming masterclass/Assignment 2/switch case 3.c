#include <stdio.h>
int main()

{
    int choice;
    printf("enter number of month: ");
    scanf("%d", &choice);

    switch (choice){
        case 1:
        printf("Month is january");
        break;

        case 2:
        printf("Month is february");
        break;

        case 3:
        printf("Month is march");
        break;

        case 4:
        printf("Month is April");
        break;

        case 5:
        printf("Month is May");
        break;

        case 6:
        printf("Month is June");
        break;

        case 7:
        printf("Month is July");
        break;

        case 8:
        printf("Month August");
        break;

        case 9:
        printf("Month is september");
        break;

        case 10:
        printf("Month is October");
        break;

        case 11:
        printf("Month is November");
        break;

        case 12:
        printf("Month is December");
        break;
        default:
        printf("Invalid input. enter a number between 1 and 12.\n");
    }
    return 0;
}