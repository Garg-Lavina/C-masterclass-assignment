#include <stdio.h>

int main()
{
    int num1, num2;
    printf("enter number; ");
    scanf("%d", &num1);
    
    printf("enter number; ");
    scanf("%d", &num2);

    if (num1==num2)
    {
        printf("the numbers are equal.\n");
    }
    
}