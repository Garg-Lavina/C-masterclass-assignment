#include <stdio.h>
int main()

{
    int unit, total_bill;
    char Customer_ID[50], name[50];

    printf("enter Customer ID");
    scanf("%49s", Customer_ID);

    printf("enter name");
    scanf("%49s", name);

    printf("Enter number of units");
    scanf("%d", &unit);

    if (unit>=100 && unit<200)
    {
        total_bill=unit*1.20;

    }
    else if (unit>=200 && unit<400)
    {
        total_bill=unit*1.50;
    }
    else if (unit>=400 && unit<600)
    {
        total_bill=unit*1.80;
    }
    else{
        total_bill=unit*2.00;
    }

    printf("customed ID: %s.\n", Customer_ID);
    printf("name: %s.\n", name);
    printf("total bill = %d.\n", total_bill);
    
    return 0;
    
}