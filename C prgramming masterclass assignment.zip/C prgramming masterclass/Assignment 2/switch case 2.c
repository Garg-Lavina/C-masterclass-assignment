#include <stdio.h>

int main()
 {
    int choice; 
    float area, a, b, r;

    printf("1. square.  \n");
    printf("2. rectangle. \n");
    printf("3. circle. \n");
    printf("4. triangle. \n");
    printf("Enter shape: ");
    scanf("%d", &choice); 

    switch(choice){
        case 1:
        printf("enter side length: \n");
        scanf("%f", &a);
            area=a*a;
            printf("area: %.2f\n", area);
            break;

        case 2:
        printf("enter length and breadth: \n");
        scanf("%f %f", &a,&b);
            area=a*b;
            printf("area: %.2f\n", area);
            break;
        case 3:
        printf("enter raius: .\n");
        scanf("%f", &r);
            area=3.14*r*r;
            printf("area: %.2f\n", area);
            break;
        case 4:
        printf("enter height and base: \n");
        scanf("%f %f", &a,&b);
            area=0.5*a*b;
            printf("area: %.2f\n", area);
            break;
        default:
            printf("Error: Invalid operator! Please use 1,2,3,4\n");
    }
    
    return 0;
}

