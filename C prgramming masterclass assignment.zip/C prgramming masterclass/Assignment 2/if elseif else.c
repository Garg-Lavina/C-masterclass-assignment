#include <stdio.h>
int main()

{
    float temp_centigrade;

    printf("enter temperature in centigrade; ");
    scanf("%f", &temp_centigrade);

    if (temp_centigrade<0)
    {
        printf("freezing weather outside");
    }
    else if (temp_centigrade>=0 && temp_centigrade<=10)
    {
        printf("very cold weather outside");
    }
    else if (temp_centigrade>10 && temp_centigrade<=20)
    {
        printf("cold weather outside");
    }
    else if (temp_centigrade>20 && temp_centigrade<=30)
    {
        printf("Normal temperature outside");
    }
    else if (temp_centigrade>30 && temp_centigrade<=40)
    {
        printf("hot weather outside");
    }
    else
    {
        printf("very hot weather outside");
    }
    return 0;

}