#include <stdio.h>

int main() {
    int a, b, c, d, e, largest;

    // Input five numbers
    printf("Enter five numbers: ");
    scanf("%d %d %d %d %d", &a, &b, &c, &d, &e);

    // Nested if to find the largest number
    if (a > b) {
        if (a > c) {
            if (a > d) {
                if (a > e) {
                    largest = a;
                } else {
                    largest = e;
                }
            } else {
                if (d > e) {
                    largest = d;
                } else {
                    largest = e;
                }
            }
        } else {
            if (c > d) {
                if (c > e) {
                    largest = c;
                } else {
                    largest = e;
                }
            } else {
                if (d > e) {
                    largest = d;
                } else {
                    largest = e;
                }
            }
        }
    } else {
        if (b > c) {
            if (b > d) {
                if (b > e) {
                    largest = b;
                } else {
                    largest = e;
                }
            } else {
                if (d > e) {
                    largest = d;
                } else {
                    largest = e;
                }
            }
        } else {
            if (c > d) {
                if (c > e) {
                    largest = c;
                } else {
                    largest = e;
                }
            } else {
                if (d > e) {
                    largest = d;
                } else {
                    largest = e;
                }
            }
        }
    }

    // Print the largest number
    printf("The largest number is: %d\n", largest);
    
    return 0;
}
