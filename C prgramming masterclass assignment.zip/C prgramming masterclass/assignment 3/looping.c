// for loop
// Write a C program to display the sum of n terms of even natural numbers.

// #include<stdio.h>

// int main(){
//     int n;
//     int sum=0;

//     printf("Enter the number of terms:");
//     scanf("%d",&n);

//     for(int i = 1; i <= n; i++){

//         printf("%d\n", i);
//         if(i%2==0){
//             sum+=i;
//         }
//     }

//     printf("Sum of first %d even natural numbers is: %d\n",n,sum);

//     return 0;
// }


// Write a program in C to display the n terms of a harmonic series and their sum.
// 1 + 1/2 + 1/3 + 1/4 + 1/5 ... 1/n terms

// #include<stdio.h>

// int main(){
//     int n;
//     float sum=0.0;

//     printf("Enter the number of terms:");
//     scanf("%d",&n);

//     printf("The harmonic series up to %d terms is:\n",n);
//     for(int i=1;i<= n;i++){
//         printf("1/%d",i);  
//         sum += 1.0 / i;     
//         if (i < n) {
//             printf("+");  
//         }
//     }
//     printf("\nSum of the first %d terms of the harmonic series is: %.4f\n",n,sum);

//     return 0;
// }


// Write a program in C to display the cube of the number up to an integer.

// #include<stdio.h>

// int main(){
//     int n;

//     printf("Enter an integer:");
//     scanf("%d",&n);

//     printf("Cubes of numbers from 1 to %d are:\n",n);
//     for(int i=1; i<=n;i++){
//         printf("Cube of %d = %d\n",i,i*i*i);  
//     }

//     return 0;
// }

//-----------------------------------------------------------------------------------------

// while loop

// Write a C program that implements a program to check if a given number is a
// palindrome using a while loop.

// #include<stdio.h>

// int main(){
//     int num,revNum = 0,remainder,orgnlNum;

//     printf("Enter an integer:");
//     scanf("%d",&num);

//     orgnlNum = num; 

//     while(num != 0){
//         remainder = num % 10;
//         revNum = revNum * 10 + remainder; 
//         num /= 10; 
//     }

//     if(orgnlNum == revNum){
//         printf("%d is a palindrome.\n", orgnlNum);
//     } else{
//         printf("%d is not a palindrome.\n", orgnlNum);
//     }

//     return 0;
// }

// Write a C program to find and print the first 10 Fibonacci numbers using a while loop.

// #include<stdio.h>

// int main(){
//     int count=1,fst=0,scnd=1,next;

//     printf("The first 10 Fibonacci numbers are:\n");

//     while(count <= 10){
//         if(count == 1){
//             printf("%d ",fst);
//         } else if (count == 2) {
//             printf("%d ",scnd);
//         } else {
//             next = fst + scnd;
//             printf("%d ",next);
//             fst = scnd;
//             scnd = next;
//         }
//         count++;
//     }

//     printf("\n");
//     return 0;
// }


// Write a C program that prompts the user to input a series of numbers until they input a
// duplicate number. Use a while loop to check for duplicates.

// #include<stdio.h>

// #define MAX_SIZE 100

// int main(){
//     int numbers[MAX_SIZE]; 
//     int num,i,count = 0;
//     int isDuplicate = 0;

//     printf("Enter a series of numbers\nThe program will stop if a duplicate is entered.\n");

//     while(1){
//         printf("Enter a number:");
//         scanf("%d",&num);

//         isDuplicate = 0;
//         for(i = 0;i<count;i++){
//             if(numbers[i] == num){
//                 isDuplicate = 1;
//                 break;
//             }
//         }

//         if(isDuplicate){
//             printf("Duplicate detected! Exiting the program.\n");
//             break;  
//         }

//         numbers[count] = num;
//         count++;

//         if(count >= MAX_SIZE){
//             printf("Maximum number of entries reached.\n");
//             break;
//         }
//     }

//     return 0;
// }

//-----------------------------------------------------------------------------------

//do while

//Write a C program that calculates the average of a set of numbers input by the user.
//The user should be able to input as many numbers as desired, and the program should
//continue until the user decides to stop

// #include<stdio.h>

// int main(){
//     int num;
//     double sum=0.0;
//     int count=0;
//     char choice;

//     printf("This program will calculate the average of numbers you enter.\n");

//     while(1){
//         printf("Enter a number: ");
//         scanf("%d",&num);
        
//         sum += num;
//         count++;

//         printf("Do you want to enter another number? (y/n): ");
//         scanf(" %c",&choice);  

//         if(choice == 'n' || choice == 'N'){
//             break;  
//         }
//     }

//     if(count > 0){
//         double average = sum / count;
//         printf("The average of the numbers you entered is: %.2f\n",average);
//     } else{
//         printf("No numbers were entered.\n");
//     }

//     return 0;
// }

// Write a C program that calculates the compound interest for a given principal amount,
//interest rate, and time period. Use a do-while loop to allow the user to input values
//multiple times.

// #include<stdio.h>
// #include<math.h>  

// int main(){
//     double principal,rate,time,amount,compoundInterest;
//     char choice;

//     do{
//         printf("Enter the principal amount:");
//         scanf("%lf",&principal);

//         printf("Enter the annual interest rate (in %%):");
//         scanf("%lf",&rate);

//         printf("Enter the time period in years:");
//         scanf("%lf",&time);

//         amount = principal * pow((1 + rate / 100), time);
//         compoundInterest = amount - principal;

//         printf("Principal Amount: %.2lf\n",principal);
//         printf("Annual Interest Rate: %.2lf%%\n",rate);
//         printf("Time Period: %.2lf years\n",time);
//         printf("Amount after %.2lf years: %.2lf\n",time,amount);
//         printf("Compound Interest: %.2lf\n",compoundInterest);

//         printf("Do you want to calculate again? (y/n): ");
//         scanf(" %c",&choice);  

//     } while (choice == 'y' || choice == 'Y');  

//     printf("Thank you for using the compound interest calculator!\n");

//     return 0;
// }


//Write a C program that prompts the user to input a series of integers until the user
//stops by entering 0 using a do-while loop. Calculate and print the sum of all positive
//integers entered.

// #include <stdio.h>

// int main(){
//     int num,sum=0;

//     do{
//         printf("Enter an integer (0 to stop):");
//         scanf("%d", &num);

//         if(num > 0){
//             sum += num;
//         }

//     } while(num != 0);  

//     printf("The sum of all positive integers entered is: %d\n",sum);

//     return 0;
// }
