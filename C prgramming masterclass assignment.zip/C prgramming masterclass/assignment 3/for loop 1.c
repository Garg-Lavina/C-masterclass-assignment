#include <stdio.h>

int main()
 {
    int n, sum = 0;

    printf("Enter the number of even natural numbers to be calculated: ");
    scanf("%d", &n);

    for (int i = 1; i <= n; i++) {
        sum += 2 * i; 
    }


    printf("The sum of the first %d even natural numbers is: %d\n", n, sum);

    return 0;
}
