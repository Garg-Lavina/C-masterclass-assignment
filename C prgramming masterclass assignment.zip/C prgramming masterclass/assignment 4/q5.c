#include <stdio.h>

int factorial(int num){
    int fact=1;
    for (int i=num; i>1; i--)
    {
        fact*=i;
    }
    return num;
    
}

float series_sum(int n){
    float sum=0.0;
    for (int i = 1; i <=n; i++)
    {
        sum+=(float)factorial(i)/i;
    }
    return sum;
    
}

int main() {
    printf("The sum of the series is: %.2f\n", series_sum(5));
    return 0;
}
