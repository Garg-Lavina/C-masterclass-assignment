#include <stdio.h>

int square_num(int num){
    return num*num;
}

int main()
{
    int number;

    printf("enter number: ");
    scanf("%d", &number);

    printf("the square of %d is %d.\n", number, square_num(number));

    return 0;
}