#include <stdio.h>

void main()
{
    int minutes, hours, total_minutes;
    printf("enter hours; ");
    scanf("%d", &hours);

    printf("enter minutes: ");
    scanf("%d", &minutes);

    total_minutes=((hours*60)+minutes);
    printf("total minutes; %d\n", total_minutes);

}