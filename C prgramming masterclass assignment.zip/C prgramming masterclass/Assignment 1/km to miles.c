#include <stdio.h>

void  main()
{
    float kmph, mph;
    printf("enter kmph");
    scanf("%f", &kmph);

    mph=kmph*0.62;
    printf("%f", mph);

}