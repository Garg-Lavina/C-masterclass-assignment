#include <stdio.h>

void  main()
{
    int breadth, length, perimeter;
    printf("enter length: ");
    scanf("%d", &length);

    printf("enter breadth: ");
    scanf("%d", &breadth);
    perimeter=(2*(length+breadth));
    printf("%d\n", perimeter);

}