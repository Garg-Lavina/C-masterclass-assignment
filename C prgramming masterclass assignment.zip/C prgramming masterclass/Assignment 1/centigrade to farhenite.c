#include <stdio.h>

void  main()
{
    float centigrade, farhenite;
    printf("enter temp. in centigrade: ");
    scanf("%f", &centigrade);

    farhenite=((centigrade*9/5)+32);
    printf("%f", farhenite);

}