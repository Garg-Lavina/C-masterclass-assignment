#include <stdio.h>

void main()
{
    char  forename[50], surname[50];
    int year_of_birth;
    printf("enter forename; ");
    scanf("%49s", forename);

    printf("enter surname; ");
    scanf("%49s", surname);

    printf("enter year of birth; ");
    scanf("%d", &year_of_birth);

    printf("%s %s %d\n", forename, surname, year_of_birth);


}
